<?php $__env->startSection('content'); ?>

        <div class="row">
            <div class="col-md-12">
                <form action="/send" class="form-signin" method="post">
                    <?php echo e(csrf_field()); ?>

                    <h2 class="form-signin-heading">Enviar mensaje como bot</h2>
                    <label for="inputText" class="sr-only">Mensaje</label>
                    <textarea name="message" type="text" id="inputText" class="form-control" placeholder="Message" required autofocus></textarea>
                    <br />
                    <button class="btn btn-lg btn-primary btn-block" type="submit">Enviar</button>
                </form>
                <br />
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-<?php echo e(Session::get('status')); ?> status-box">
                        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>