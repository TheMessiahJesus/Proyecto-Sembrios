<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <h1>IMPORTANTE Antes de poder enviar:</h1>
        <p class="lead">Deben de abrir el enlace del chat para formar parte del mismo, caso contrario no visualizaran el mensaje al ser grupo privado.<br /> Enlace: <a style="word-break: break-all;" href="<?php echo e(env('GROUP_INVITE_LINK')); ?>" target="_blank"><?php echo e(env('GROUP_INVITE_LINK')); ?></a></p>
        <p>Happy Garden les da la bienvenida.</p>
        <p><a class="btn btn-lg btn-success" href="/send" role="button"><i class="fa fa-envelope"></i> Enviar Mensaje</a></p>
    </div>

    <div class="row marketing">
        <div class="col-lg-6">
            <h4>Telegram Bot</h4>
            <p>El proyecto usa: <a href="https://telegram-bot-sdk.readme.io/" target="_blank">Telegram Bot API PHP SDK</a>.
            Al enviar el mensaje revisar el grupo de telegram.
            </p>
            <h4>Telegram Group</h4>
            <p>El Bot enviara el mensaje al grupo vinculado de Telegram. El grupo posee otros usuarios de HappyGarden por favor mantener el respeto</p>
          </div>

        <div class="col-lg-6">
            <h4>Laravel</h4>
            <p>El proyecto usa laravel para su implementacion</p>
            <h4>Programa</h4>
            <p>El programa se encuentra en: <a href="https://github.com/chaosdrake9/BotTelegramRiegosNT/">del repositorio GitHub</a>.</p>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>