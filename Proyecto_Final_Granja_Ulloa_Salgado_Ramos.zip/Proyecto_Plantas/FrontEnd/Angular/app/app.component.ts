import { Component } from '@angular/core';
//el decorator le dice a angular que la clase no es simplemente una clase, sino un componente
@Component({//Metadata Decorator_FUncion que se adiere a la clase que se encuentra abajo
  selector: 'app-root',//levanta como root
  templateUrl: './app.component.html',//vista por defecto
  styleUrls: ['./app.component.css']//url de estilos para la hoja de html
})
export class AppComponent {
  title = 'Proyecto de Plantas';
}
