import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VentanaManualComponent } from './ventana-manual.component';

describe('VentanaManualComponent', () => {
  let component: VentanaManualComponent;
  let fixture: ComponentFixture<VentanaManualComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VentanaManualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VentanaManualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
