import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navderregistrar',
  templateUrl: './navderregistrar.component.html',
  styleUrls: ['./navderregistrar.component.css']
})
export class NavderregistrarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
