import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavderregistrarComponent } from './navderregistrar.component';

describe('NavderregistrarComponent', () => {
  let component: NavderregistrarComponent;
  let fixture: ComponentFixture<NavderregistrarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavderregistrarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavderregistrarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
