import { Routes, RouterModule } from "@angular/router";
import { RegistrarPrincipalComponent } from "./registrar-principal/registrar-principal.component";
import { IngresoprincipalComponent } from "./ingresoprincipal/ingresoprincipal.component";
import { Manual1Component } from "./manual1/manual1.component";
import { Manual2Component } from "./manual2/manual2.component";
import { AyudaComponent } from "./ayuda/ayuda.component";

const app_routes:Routes = [
    { path: 'registrar-principal', component: RegistrarPrincipalComponent },
    { path: 'ingresoprincipal', component: IngresoprincipalComponent },

    { path: '**', pathMatch: 'full', redirectTo: 'registrar-principal' }
];

export const app_routing = RouterModule.forRoot(app_routes); //, { useHash:true }
