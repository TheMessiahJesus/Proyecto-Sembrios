import { Component, OnInit } from '@angular/core';
import { Http } from '../../../node_modules/@angular/http';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import {
  AuthService,
  FacebookLoginProvider,
} from 'angular5-social-login';
@Component({
  selector: '[app-test]',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  nombre:'';
  celular:'';
  correo:'';
  contrasenia:'';
  found:boolean;

  constructor(private socialAuthService: AuthService ,private httpClient: HttpClient) {  }
  public socialSignIn(socialPlatform : string) {
    let socialPlatformProvider;
    if(socialPlatform == "facebook"){
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    }
    
    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
        console.log(socialPlatform+" sign in data : " , userData);
        // Now sign-in with userData

      }
    );
  }

  onNombreKeyUp(event:any){
    this.nombre=event.target.value;
    this.found=false;
  }
  onCelularKeyUp(event:any){
    this.celular=event.target.value;
    this.found=false;
  }
  onCorreoKeyUp(event:any){
    this.correo=event.target.value;
    this.found=false;
  }
  onContraseniaKeyUp(event:any){
    this.contrasenia=event.target.value;
    this.found=false;
  }

  httpOptions = {
    headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'my-auth-token'
      })
    };

  getProfile(){
    this.httpClient.get('http://localhost:8000/api/usuario/?nombre='+this.nombre)
    .subscribe(
      (data:any[]) => {
        if(data.length){
          console.log(this.nombre);
          this.contrasenia= data[0].contrasenia;
          console.log(this.contrasenia);
          this.found=true;
        } 
      }
    )
  }
  postProfile(){
    this.httpClient.post('http://localhost:8000/api/usuarioPost?nombre='+this.nombre+'&celular='+this.celular+'&correo='+this.correo+'&contrasenia='+this.contrasenia,
    {
      nombre:this.nombre,
      celular:this.celular,
      correo:this.correo,
      contrasenia:this.contrasenia
    })
    .subscribe(
      (data:any[]) => {
          console.log(data);
      }
    )
  }

  ngOnInit() {
  }
}
