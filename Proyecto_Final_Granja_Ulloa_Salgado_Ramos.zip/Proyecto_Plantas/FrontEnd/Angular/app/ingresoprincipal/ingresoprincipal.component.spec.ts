import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IngresoprincipalComponent } from './ingresoprincipal.component';

describe('IngresoprincipalComponent', () => {
  let component: IngresoprincipalComponent;
  let fixture: ComponentFixture<IngresoprincipalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IngresoprincipalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IngresoprincipalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
