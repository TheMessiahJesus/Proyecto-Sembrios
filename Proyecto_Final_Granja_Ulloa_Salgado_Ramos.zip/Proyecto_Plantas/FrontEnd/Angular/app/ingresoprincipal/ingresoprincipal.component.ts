import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ingresoprincipal',
  templateUrl: './ingresoprincipal.component.html',
  styleUrls: ['./ingresoprincipal.component.css']
})
export class IngresoprincipalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
