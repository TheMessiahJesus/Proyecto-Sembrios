import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manual1',
  templateUrl: './manual1.component.html',
  styleUrls: ['./manual1.component.css']
})
export class Manual1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
