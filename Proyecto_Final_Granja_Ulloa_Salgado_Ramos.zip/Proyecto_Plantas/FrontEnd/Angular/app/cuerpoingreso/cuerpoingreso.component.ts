import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cuerpoingreso',
  templateUrl: './cuerpoingreso.component.html',
  styleUrls: ['./cuerpoingreso.component.css']
})
export class CuerpoingresoComponent implements OnInit {
  fullImagePath: string;
  constructor() {
    this.fullImagePath = './assets/Asset6.svg';
   }
  ngOnInit() {
  }

}
