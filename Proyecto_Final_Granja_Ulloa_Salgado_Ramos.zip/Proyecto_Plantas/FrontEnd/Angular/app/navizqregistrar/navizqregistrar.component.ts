import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navizqregistrar',
  templateUrl: './navizqregistrar.component.html',
  styleUrls: ['./navizqregistrar.component.css']
})
export class NavizqregistrarComponent implements OnInit {
  fullImagePath: string;
  constructor() {
    this.fullImagePath = './assets/Asset6.svg';
   }
  ngOnInit() {
  }

}
