import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavizqregistrarComponent } from './navizqregistrar.component';

describe('NavizqregistrarComponent', () => {
  let component: NavizqregistrarComponent;
  let fixture: ComponentFixture<NavizqregistrarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavizqregistrarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavizqregistrarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
