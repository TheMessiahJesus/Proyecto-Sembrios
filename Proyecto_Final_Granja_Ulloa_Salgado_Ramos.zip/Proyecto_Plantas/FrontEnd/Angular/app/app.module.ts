import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { RegistrarPrincipalComponent } from './registrar-principal/registrar-principal.component';
import { NavderregistrarComponent } from './navderregistrar/navderregistrar.component';
import { NavizqregistrarComponent } from './navizqregistrar/navizqregistrar.component';

//Rutas
import { RouterModule } from '@angular/router';
import { app_routing } from './app.routes';
import { IngresoprincipalComponent } from './ingresoprincipal/ingresoprincipal.component';
import { ShowHidePasswordModule } from 'ngx-show-hide-password';
import { CuerpoingresoComponent } from './cuerpoingreso/cuerpoingreso.component';
import {
  SocialLoginModule,
  AuthServiceConfig,
  FacebookLoginProvider,
} from "angular5-social-login";
export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
      [
        {
          id: FacebookLoginProvider.PROVIDER_ID,
          provider: new FacebookLoginProvider("271241920301913")
        },
      ],
  );
  return config;
}
@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    RegistrarPrincipalComponent,
    NavderregistrarComponent,
    NavizqregistrarComponent,
    IngresoprincipalComponent,
    CuerpoingresoComponent

  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    RouterModule, 
    ShowHidePasswordModule.forRoot(),
    app_routing,
    SocialLoginModule
  ],
  providers: [
    {
      provide: AuthServiceConfig,
      useFactory: getAuthServiceConfigs
    }
  ],bootstrap: [AppComponent]
})
export class AppModule { }
