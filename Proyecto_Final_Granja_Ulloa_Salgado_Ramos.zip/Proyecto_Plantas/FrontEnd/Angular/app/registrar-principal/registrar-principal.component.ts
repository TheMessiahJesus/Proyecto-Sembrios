import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrar-principal',
  templateUrl: './registrar-principal.component.html',
  styleUrls: ['./registrar-principal.component.css']
})
export class RegistrarPrincipalComponent implements OnInit {
  constructor() {
   }

  ngOnInit() { 
  }

}
