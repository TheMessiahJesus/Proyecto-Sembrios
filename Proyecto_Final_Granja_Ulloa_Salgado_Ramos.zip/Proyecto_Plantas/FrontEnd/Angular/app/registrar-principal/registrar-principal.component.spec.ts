import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrarPrincipalComponent } from './registrar-principal.component';

describe('RegistrarPrincipalComponent', () => {
  let component: RegistrarPrincipalComponent;
  let fixture: ComponentFixture<RegistrarPrincipalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrarPrincipalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrarPrincipalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
