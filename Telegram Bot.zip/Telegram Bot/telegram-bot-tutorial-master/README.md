# telegram-bot-tutorial

[![Say thanks](https://img.shields.io/badge/SayThanks.io-%E2%98%BC-1EAEDB.svg)](https://saythanks.io/to/n1try)

Code of my video tutorial on how to create a basic **ToDo** application as a **Telegram bot** using Node.js and the [telegram-node-bot](https://github.com/Naltox/telegram-node-bot) framework.

[![youtube_thumbnail](http://img.youtube.com/vi/Te7HcRhwOI4/0.jpg)](http://www.youtube.com/watch?v=Te7HcRhwOI4 "Tutorial: How to create a Telegram Bot with Node.js")

[![Buy me a coffee](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://buymeacoff.ee/n1try)

## License
MIT @ [Ferdinand Mütsch](https://ferdinand-muetsch.de)
