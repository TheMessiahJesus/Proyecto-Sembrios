<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\usuario;

class UsuarioDP extends Controller
{
    public function index()//GET
	{
		return \App\usuario::all();
	}
    public function show($id)//GET
	{
		return \App\usuario::find($id);
	}
	public function store(Request $request)//POST
	{
		return \App\usuario::create($request->all());
	}
	public function edit(Request $request, $id)//PUT
	{
		$registro = \App\usuario::findOrFail($id);
		$registro -> update($request->all());

		return $registro;
	}
	public function destroy($id)//DELETE
	{
		$registro = \App\usuario::findOrFail($id);
		$registro -> delete();

		return 204; //hubo una ejecución de instruccion exitosa]
	}
}
