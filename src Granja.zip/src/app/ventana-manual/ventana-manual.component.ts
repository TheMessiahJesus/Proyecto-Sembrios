import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ventana-manual',
  templateUrl: './ventana-manual.component.html',
  styleUrls: ['./ventana-manual.component.css']
})
export class VentanaManualComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
