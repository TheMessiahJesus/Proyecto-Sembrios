import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manual2',
  templateUrl: './manual2.component.html',
  styleUrls: ['./manual2.component.css']
})
export class Manual2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
