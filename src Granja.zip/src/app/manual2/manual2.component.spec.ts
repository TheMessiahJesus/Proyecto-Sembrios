import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Manual2Component } from './manual2.component';

describe('Manual2Component', () => {
  let component: Manual2Component;
  let fixture: ComponentFixture<Manual2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Manual2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Manual2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
