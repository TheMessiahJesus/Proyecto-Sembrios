import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { Manual1Component } from './manual1/manual1.component';
import { Manual2Component } from './manual2/manual2.component';
import { VentanaManualComponent } from './ventana-manual/ventana-manual.component';
import { HttpClientModule } from '@angular/common/http';
import { AyudaComponent } from './ayuda/ayuda.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    Manual1Component,
    Manual2Component,
    VentanaManualComponent,
    AyudaComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
